const questions = [
    // Questions from Leviticus to Hezekiah
    {
        question: "Which offering in Leviticus was meant for atonement of sin?",
        options: ["Burnt Offering", "Sin Offering", "Grain Offering", "Peace Offering"],
        answer: 1
    },
    {
        question: "Who was allowed to enter the Most Holy Place once a year in Leviticus?",
        options: ["Priest", "High Priest", "Levite", "Elder"],
        answer: 1
    },
    {
        question: "What food was provided by God to the Israelites in the wilderness?",
        options: ["Manna", "Quail", "Bread", "Honey"],
        answer: 0
    },
    {
        question: "Who led the Israelites into the Promised Land?",
        options: ["Moses", "Aaron", "Joshua", "Caleb"],
        answer: 2
    },
    {
        question: "Which city did the Israelites conquer first in the Promised Land?",
        options: ["Ai", "Jericho", "Bethel", "Hebron"],
        answer: 1
    },
    {
        question: "Who was the only female judge of Israel?",
        options: ["Deborah", "Hannah", "Ruth", "Esther"],
        answer: 0
    },
    {
        question: "What was the name of Ruth’s first husband?",
        options: ["Elimelech", "Boaz", "Mahlon", "Chilion"],
        answer: 2
    },
    {
        question: "Who anointed David as king?",
        options: ["Saul", "Samuel", "Nathan", "Elijah"],
        answer: 1
    },
    {
        question: "What was David's capital city?",
        options: ["Jericho", "Bethlehem", "Jerusalem", "Hebron"],
        answer: 2
    },
    {
        question: "Which king built the temple in Jerusalem?",
        options: ["David", "Saul", "Solomon", "Hezekiah"],
        answer: 2
    },
    {
        question: "Who was taken up to heaven in a whirlwind?",
        options: ["Elijah", "Elisha", "Moses", "David"],
        answer: 0
    },
    {
        question: "Which tribe of Israel was responsible for the priesthood?",
        options: ["Judah", "Benjamin", "Levi", "Dan"],
        answer: 2
    },
    {
        question: "Which king prayed for wisdom and received it?",
        options: ["David", "Solomon", "Hezekiah", "Josiah"],
        answer: 1
    },
    {
        question: "Which prophet confronted King Ahab about his sin?",
        options: ["Elijah", "Elisha", "Jeremiah", "Isaiah"],
        answer: 0
    },
    {
        question: "Who was the wife of Ahab, known for her wickedness?",
        options: ["Jezebel", "Esther", "Deborah", "Ruth"],
        answer: 0
    },
    {
        question: "What did King Solomon build in Jerusalem?",
        options: ["A temple", "A palace", "A wall", "A well"],
        answer: 0
    },
    {
        question: "Who was thrown into the lion’s den?",
        options: ["Daniel", "David", "Elijah", "Moses"],
        answer: 0
    },
    {
        question: "What did Jonah do instead of going to Nineveh?",
        options: ["Went to Tarshish", "Went to Egypt", "Went to Babylon", "Stayed in Israel"],
        answer: 0
    },
    {
        question: "Which prophet was known for performing many miracles, including raising the dead?",
        options: ["Elijah", "Elisha", "Isaiah", "Jeremiah"],
        answer: 1
    },
    {
        question: "Which king reigned over Israel during the divided kingdom and was known for his evil deeds?",
        options: ["Jeroboam", "Ahab", "Hezekiah", "Rehoboam"],
        answer: 1
    }
];

let currentQuestionIndex = 0;
let score = 0;
let timeLeft = 30;
let timer;

function loadQuestion() {
    // Ensure we don't go out of bounds of the questions array
    if (currentQuestionIndex < questions.length) {
        const currentQuestion = questions[currentQuestionIndex];
        document.getElementById('question').textContent = currentQuestion.question;
        
        // Load options
        currentQuestion.options.forEach((option, index) => {
            document.getElementById('option' + index).textContent = String.fromCharCode(65 + index) + ": " + option;
        });

        resetTimer();
    } else {
        endQuiz();
    }
}

function selectAnswer(selectedOption) {
    const currentQuestion = questions[currentQuestionIndex];
    if (selectedOption === currentQuestion.answer) {
        score++;
        document.getElementById('score').textContent = "Score: " + score;
    }
    nextQuestion();
}

function nextQuestion() {
    currentQuestionIndex++;
    loadQuestion();
}

function resetTimer() {
    clearInterval(timer);
    timeLeft = 30;
    document.getElementById('timer').textContent = "Time left: " + timeLeft + " seconds";
    timer = setInterval(() => {
        timeLeft--;
        document.getElementById('timer').textContent = "Time left: " + timeLeft + " seconds";
        if (timeLeft <= 0) {
            nextQuestion();
        }
    }, 1000);
}

function endQuiz() {
    clearInterval(timer);
    document.getElementById('question-container').innerHTML = `<h2>Quiz Over!</h2><p>Your final score is ${score}</p>`;
    document.getElementById('controls').style.display = "none";
}

// Start the quiz when the page loads
window.onload = function() {
    loadQuestion();
};
